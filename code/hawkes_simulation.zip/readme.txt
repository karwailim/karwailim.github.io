Code corresponds to the paper: 

Simulation and Calibration of a Fully Bayesian 
Marked Multidimensional Hawkes Process with Dissimilar Decays

=================
To use this code:

1. Edit testSimulate.m to change parameters.

2. Run testSimulate.m to simulate Hawkes process.