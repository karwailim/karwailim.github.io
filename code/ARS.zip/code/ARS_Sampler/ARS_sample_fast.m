function [ samples ] = ARS_sample_fast( N, llik_func, ldev_func, init, bounds )
%ARS_SAMPLE Sample using ARS
%   Derivative-based ARS method
%
%  Variables:
%           N = number of samples
%   llik_func = log likelihood function
%   ldev_func = derivative of log likelihood function
%        init = vector of initial points (for envelope & squeezing function)
%      bounds = boundary of the distribution support
%
% Author: KW Lim
% Last modified: 21 April 2016


% initialise generated values
samples = nan(N,1);

% initial points for envelope and squeezing function
x = sort([init, bounds]);   % include left right bounds

% evaluate the log likelihood h(x)
llik = llik_func(x);        % include left right bounds

% evaluate the gradients h'(x)
grad = ldev_func(x);        % include left right bounds

% number of points
K = length(x);              % include left right bounds


% check correctness of initial points before proceeding
if length(init) <= 1
    error('ERROR: Not enough initial points!')
end
if or(min(init) < min(bounds), max(init) > max(bounds))
    error('ERROR: Initial points out of bound!')
end
if ~and(grad(2) > 0, grad(K-1) < 0)
    error('ERROR: Initial points invalid (derivatives same sign)')
end
if any(grad == 0)
    error('ERROR: Initial point have derivative zero!')
end
if length(unique(init)) ~= length(init)
    error('ERROR: Initial points repeated more than once!')
end


% find intersections of the tangents
ind = 2:(K-2);

z = [min(bounds), ...
    (llik(ind+1) - llik(ind) - x(ind+1).*grad(ind+1) + x(ind).*grad(ind)) ...
        ./ (grad(ind) - grad(ind+1)), ...
    max(bounds)];


% piecewise upper hull (for envelope) function u(x) follows this form
% u_k(x) = h(x_j) + (x - x_j)*d(x_j)
% for j = 1,2; x in [z_(j-1), z_j]

% find u(z), upper hull at the intersection
indz = 2:(K-1);
   
u_z = [ llik(2) + (z(1) - x(2))*grad(2) , ...  % the first u_z use the gradient of the next piece
        llik(indz) + (z(indz) - x(indz)).*grad(indz) ];
    
exp_u_z = exp(u_z);

% piecewise lower hull (for squeezing) function l(x) follows this form
% l_k(x) = ((x_(j+1) - x)*h(x_j) + (x - x_j)*h(x_(j+1))) / (x_(j+1) - x_j)
% for j = 1; x in [x_j, x_(j+1)]
% note l_k(x) = -inf for all other x (x < x1, x > x2)

% to find the envelope function, we first compute the normalising constant Q
cdf_part_z = [0, ...
              1./grad(indz) .* (exp_u_z(indz) - exp_u_z(indz-1))];

cdf_z = cumsum(cdf_part_z);
Q = cdf_z(end);

iter = 1;
while iter <= N
    
    % sample a standard uniform random variable to generate a sample x via the
    % inverse cdf method
    w1 = rand;  % 0.8389 with seed 11111
    
    % find x corresponds to w1, we times w1 by Q since it is easier to work on
    % the un-normalised space
    Qw1 = Q*w1;
    
    u_x = nan;  % initialise
    for j = 2:length(cdf_z)
        if Qw1 < cdf_z(j)
            u_x = log((Qw1 - cdf_z(j-1))*grad(j) + exp_u_z(j-1));
            sampled_x = x(j) + (u_x - llik(j))/grad(j);
            break
        end
    end
    
    % squeezing test
    w2 = rand;  % 0.4789
    
    
    % find j such that [sampled_x > x(j)] AND [sampled_x < x(j+1)]
    for k = 1:(length(x)-1)
        if and(sampled_x > x(k), sampled_x < x(k+1))
            j = k;
            break
        end
    end
    
    % compute l_x for squeezing test
    if and(j > 1, j < length(x)-1)
        l_x = ((x(j+1) - sampled_x)*llik(j) + (sampled_x - x(j))*llik(j+1)) / (x(j+1) - x(j));
    else
        l_x = -inf;
    end
    
    
    squeeze_ratio = exp(l_x - u_x);
    
    % if success
    if w2 < squeeze_ratio
        samples(iter) = sampled_x;
        iter = iter + 1;
        % if fail
    else
        % perform rejection test if failed squeezing test
        h_x = llik_func(sampled_x);
        acceptance_ratio = exp(h_x - u_x);
        
        % if success
        if w2 < acceptance_ratio
            samples(iter) = sampled_x;
            iter = iter + 1;
        end
        
        %%% update envelope and squeezing function if evaluate h_x
        % update x
        x = [x(1:j), sampled_x, x(j+1:end)];
        % update llik
        llik = [llik(1:j), h_x, llik(j+1:end)];
        % update grad
        grad = [grad(1:j), ldev_func(sampled_x), grad(j+1:end)];
        % update z
        if j == 1
            % boundary case
            ind = j+1;
        elseif j == length(x)-2  % note x already increase in size
            % boundary case
            ind = j;
        else
            ind = j:j+1;
        end

        z = [z(1:ind(1)-1), ...
            (llik(ind+1) - llik(ind) - x(ind+1).*grad(ind+1) + x(ind).*grad(ind)) ...
                ./ (grad(ind) - grad(ind+1)), ...
            z(ind(end):end)];
        % update u_z
        indu = j:j+1;
        u_z = [u_z(1:indu(1)-1), ...
            llik(indu) + (z(indu) - x(indu)).*grad(indu), ...
            u_z(indu(end):end)];
        % change u_z(1) if j == 1 (use the gradient of next piece)
        if j == 1
            u_z(1) = llik(2) + (z(1) - x(2))*grad(2);  % the first u_z use the gradient of the next piece
        end
        
        exp_u_z = [exp_u_z(1:indu(1)-1), exp(u_z(indu)), exp_u_z(indu(end):end)];
        % update cdf_part
        if j == 1
            % boundary case
            indc = j+1:j+2;
        elseif j == length(x)-2  % note x already increase in size
            % boundary case
            indc = j:j+1;
        else
            indc = j:j+2;
        end

        cdf_part_z = [cdf_part_z(1:indc(1)-1), ...
            1./grad(indc) .* (exp_u_z(indc) - exp_u_z(indc-1)), ...
            cdf_part_z(indc(end):end)];
        
        cdf_z = cumsum(cdf_part_z);
        Q = cdf_z(end);
    end
end
end
