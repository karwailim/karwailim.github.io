%%% This script test the implemented ARS method by simulating gamma dist.

clc; clear all; close all;  % clear console

% set seed
rng(2848428);

%% SETTINGS

% number of samples
N = 1000000;

% parameters for normal distribution
shape = 3.0;
scale = 2.0;

% support of the distribution
left_bound  = 1e-99;
right_bound = 9e99;
bounds = [left_bound, right_bound];

% log of likelihood, h(x) = log g(x)
llik_func = @(x) (shape-1).*log(x) - x./scale;

% first derivative of d(x) = d/dx h(x)
ldev_func = @(x) (shape-1)./x - 1./scale;

% initial points
init = [1, 2, 5, 7];

% generate samples using ARS
tic % start timer 
samples = ARS_sample_fast(N, llik_func, ldev_func, init, bounds);
toc % end timer

mu_est  = mean(samples)
var_est = var(samples)

% KS test
% h = 0 => correct distribution, h = 1 => not correct, p is p-value
[h,p]   = kstest(samples, [samples, gamcdf(samples, shape, scale)])
