%%% This script test the implemented ARS method by simulating normal dist.

clc; clear all; close all;  % clear console

% set seed
rng(151891);

%% SETTINGS

% number of samples
N = 1000000;

% parameters for normal distribution
mu     = 3.0;
sigma2 = 5.0;

% support of the distribution
left_bound  = -9e99;
right_bound = 9e99;
bounds = [left_bound, right_bound];

% log of likelihood, h(x) = log g(x)
llik_func = @(x) -1/2 .* (x - mu).^2 ./ sigma2;

% first derivative of d(x) = d/dx h(x)
ldev_func = @(x) -(x - mu) ./ sigma2;

% initial points
init = [-3, -1, 2, 4];


% generate samples using ARS
tic % start timer 
samples = ARS_sample_stable(N, llik_func, ldev_func, init, bounds);
toc % end timer

mu_est  = mean(samples)
var_est = var(samples)

% KS test
% h = 0 => standard normal, h = 1 => not standard normal, p is p-value
[h,p]   = kstest((samples - mu)./sqrt(sigma2))  
[h,p]   = kstest(samples, [samples normcdf(samples, mu, sqrt(sigma2))])
