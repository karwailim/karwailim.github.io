%%% This script provides step-by-step tutorial to illustrate the adaptive
%%% rejection sampling (ARS) method.
%%% In this example, we sample from normal (gaussian) distribution.

% clc; 
clear all; close all;  % clear console

% set seed
rng(11111);


%% SETTINGS

% parameters for normal distribution
mu     = 0;
sigma2 = 1;

% support of the distribution
left_bound  = -inf;
right_bound = inf;


% likelihood up to a proportionality constant
g = @(x) exp( -1/2 .* (x - mu).^2 ./ sigma2 );

% log of likelihood g(x)
h = @(x) -1/2 .* (x - mu).^2 ./ sigma2;

% first derivative of h(x)
d = @(x) -(x - mu) ./ sigma2;


%% ARS DEMO

% choose two starting points x1, x2
x1 = -1;
x2 =  2;

x = [x1, x2];

% evaluate the log likelihood h(x)
llik1 = h(x1);
llik2 = h(x2);

llik = [llik1, llik2];

% evaluate the gradients h'(x)
grad1 = d(x1);
grad2 = d(x2);

grad = [grad1, grad2];

% find intersections of the tangents for x1 and x2
z0 = left_bound;
z1 = (llik2 - llik1 - x2*grad2 + x1*grad1) / (grad1 - grad2);
z2 = right_bound;

z = [z0, z1, z2];

% piecewise upper hull (for envelope) function u(x) follows this form
% u_k(x) = h(x_j) + (x - x_j)*d(x_j)
% for j = 1,2; x in [z_(j-1), z_j]

% find u(z), upper hull at the intersection
u_z0 = -inf;
u_z1 = llik1 + (z1 - x1)*grad1;
u_z2 = llik2 + (z2 - x2)*grad2;

u_z = [u_z0, u_z1, u_z2];

% piecewise lower hull (for squeezing) function l(x) follows this form
% l_k(x) = ((x_(j+1) - x)*h(x_j) + (x - x_j)*h(x_(j+1))) / (x_(j+1) - x_j)
% for j = 1; x in [x_j, x_(j+1)]
% note l_k(x) = -inf for all other x (x < x1, x > x2)

% to find the envelope function, we first compute the normalising constant Q
cdf_part_z1 = 1/grad1 * (exp(u_z1) - exp(u_z0));  % area under the curve for the first piece
cdf_part_z2 = 1/grad2 * (exp(u_z2) - exp(u_z1));

cdf_part_z = [cdf_part_z1, cdf_part_z2];

Q = sum(cdf_part_z);
Q_ = (1/grad1 - 1/grad2)*exp(u_z1); % for checking

% piecewise cdf for the envelope function, \int exp u(x) follows this form
% c_k(x) = 1/norm_const * (\int_(u<k) c_u(x) + \int_x c_k(x) ) 
% for j = 1,2; x in [z_{j-1}, z_j]


% sample a standard uniform random variable to generate a sample x via the
% inverse cdf method
w1 = rand;  % 0.8389 with seed 11111

% find x corresponds to w1, we times w1 by Q since it is easier to work on
% the un-normalised space
Qw1 = Q*w1;

cdf_z = cumsum(cdf_part_z);

u_x = nan;
if Qw1 < cdf_z(1)  % belong to first piece
    u_x = log(Qw1 * grad1);
    sampled_x = x1 + (u_x - llik1)/grad1;
elseif Qw1 < cdf_z(2)
    A2 = (Qw1 - cdf_z(1))*grad2 + exp(u_z1);
    u_x = log(A2);
    sampled_x = x2 + (u_x - llik2)/grad2;
end

% squeezing test
w2 = rand;  % 0.4789

squeezing_test = false;
for j = 1:(length(x)-1)
    if and(sampled_x > x(j), sampled_x < x(j+1))
        l_x = ((x(j+1) - sampled_x)*llik(j) + (sampled_x - x(j))*llik(j+1)) / (x(j+1) - x(j));
        squeeze_ratio = exp(l_x - u_x);
        squeezing_test = w2 < squeeze_ratio;  % 0.4789 < 0.1818, therefore reject
    end
end

% display test result
squeezing_test %#ok<NOPTS>
% if the test pass we do not have to perform the acceptance/rejection test


% acceptance rejection test
rejection_test = false;
h_x = nan;
for j = 1:(length(x)-1)
    if and(sampled_x > x(j), sampled_x < x(j+1))
        h_x = h(sampled_x);
        acceptance_ratio = exp(h_x - u_x);
        rejection_test = w2 < acceptance_ratio;  % 0.4789 <  0.5242, therefore accept
    end
end

% display test result
rejection_test %#ok<NOPTS>
% if the test pass then we accept the sample, in any case we update the
% envelope function and squeezing function since we have evaluated h(x*)


%% PLOT

left_xlim  = -5;
right_xlim =  5;

granularity = 0.01;

% draw log likelihood, upper hull and lower hull function
figure;
hold on;

    % plot log likelihood
    plot_x = left_xlim:granularity:right_xlim;  % range of x for plot
    plot_y = h(plot_x);
    plot(plot_x,plot_y,'color', 'blue');

    % plot upper hull function
    plot_u = inf(size(plot_x)); % initialise
    for j = 1:length(x)
        indice = and(z(j) <= plot_x, plot_x < z(j+1));  % indice of plot_x in abscissae k
        plot_u(indice) = llik(j) + (plot_x(indice) - x(j)).*grad(j);
    end
    plot(plot_x,plot_u,'color','red');

    % mark tangent points
    plot(x, llik, 'k+');

    % plot lower hull function
    plot_l = -inf(size(plot_x)); % initialise
    for j = 1:(length(x)-1)
        indice = and(x(j) <= plot_x, plot_x < x(j+1));  % indice of plot_x in abscissae k
        plot_l(indice) = ((x(j+1) - plot_x(indice)).*llik(j) + (plot_x(indice) - x(j)).*llik(j+1)) ./ (x(j+1) - x(j));
    end
    plot(plot_x,plot_l,'color','green');  % squeezing function between x's 

    YL = ylim;  % get the y limits
    line([x(1) x(1)], [YL(1) llik(1)], 'color','green'); % squeezing function outside x's = -inf
    line([x(end) x(end)], [YL(1) llik(end)], 'color','green'); % squeezing function outside x's = -inf

    % axis([10,inf,-0.005,0.015]);
    xlabel('x'); % x-axis label
    ylabel('log likelihood'); % y-axis label

% draw the likelihood, envelope function and the squeezing function
figure;
hold on;

    % plot likelihood
    plot_f = g(plot_x);
    plot(plot_x,plot_f,'color', 'blue');

    % envelope function
    plot(plot_x,exp(plot_u), 'color', 'red');

    % squeezing function
    plot(plot_x,exp(plot_l), 'color', 'green');

    % mark tangent points
    plot(x, exp(llik), 'k+');


    % axis([10,inf,-0.005,0.015]);
    xlabel('x'); % x-axis label
    ylabel('likelihood'); % y-axis label

% draw the cdf of the envelope function
figure;
hold on;

    % plot cdf
    plot_c = zeros(size(plot_x)); % initialise
    cum_temp = 0;  % temporary variable to store the cumulative
    for j = 1:length(x)
        indice = and(z(j) <= plot_x, plot_x < z(j+1));  % indice of plot_x in abscissae k
        plot_c(indice) = cum_temp + 1./grad(j).*(exp(plot_u(indice)) - exp(u_z(j)));
        cum_temp = cum_temp + 1/grad(j)*(exp(u_z(j+1)) - exp(u_z(j)));
    end
    plot_c = plot_c / cum_temp;
    plot(plot_x,plot_c,'color','red');

    % plot the piecewise changing point
    YL = ylim;  % get the y limits
    for j = 1:length(z)
        line([z(j) z(j)], YL, 'color','blue', 'linestyle', ':'); 
    end

    % plot the sample_x
    XL = xlim;
    line([sampled_x sampled_x], [YL(1) w1], 'color','green', 'linestyle', ':'); 
    line([XL(1) sampled_x], [w1 w1], 'color','green', 'linestyle', ':'); 

    xlabel('x'); % x-axis label
    ylabel('cumulative density function'); % y-axis label


%% UPDATE ENVELOPE AND SQUEEZING FUNCTIONS (NAIVE WAY)

% We add the sampled x* to the list of x and update the envelope and
% squeezing function

x = sort([left_bound, x, sampled_x, right_bound]);
% x = sort([left_bound, x, right_bound]);  % for testing (check with above demo)

% evaluate the log likelihood h(x)
llik = h(x);

% evaluate the gradients h'(x)
grad = d(x);

% number of points
K = length(x);

% find intersections of the tangents
ind = 2:(K-2);

z = [left_bound, ...
    (llik(ind+1) - llik(ind) - x(ind+1).*grad(ind+1) + x(ind).*grad(ind)) ...
        ./ (grad(ind) - grad(ind+1)), ...
    right_bound];


% piecewise upper hull (for envelope) function u(x) follows this form
% u_k(x) = h(x_j) + (x - x_j)*d(x_j)
% for j = 1,2; x in [z_(j-1), z_j]

% find u(z), upper hull at the intersection
indz = 2:(K-1);
   
u_z = [ llik(2) + (z(1) - x(2))*grad(2) , ...  % the first u_z use the gradient of the next piece
        llik(indz) + (z(indz) - x(indz)).*grad(indz) ];
    
exp_u_z = exp(u_z);

% piecewise lower hull (for squeezing) function l(x) follows this form
% l_k(x) = ((x_(j+1) - x)*h(x_j) + (x - x_j)*h(x_(j+1))) / (x_(j+1) - x_j)
% for j = 1; x in [x_j, x_(j+1)]
% note l_k(x) = -inf for all other x (x < x1, x > x2)

% to find the envelope function, we first compute the normalising constant Q
cdf_part_z = 1./grad(indz) .* (exp_u_z(indz) - exp_u_z(indz-1));

Q = sum(cdf_part_z);

% piecewise cdf for the envelope function, \int exp u(x) follows this form
% c_k(x) = 1/norm_const * (\int_(u<k) c_u(x) + \int_x c_k(x) ) 
% for j = 1,2; x in [z_{j-1}, z_j]



%% PLOT UPDATED ENVELOPE AND SQUEEZING FUNCTION

left_xlim  = -5;
right_xlim =  5;

granularity = 0.01;

% draw log likelihood, upper hull and lower hull function
figure;
hold on;

% plot log likelihood
plot_x = left_xlim:granularity:right_xlim;  % range of x for plot
plot_y = h(plot_x);
plot(plot_x,plot_y,'color', 'blue');

% plot upper hull function
plot_u = inf(size(plot_x)); % initialise
for j = 1:length(z)-1
    indice = and(z(j) <= plot_x, plot_x < z(j+1));  % indice of plot_x in abscissae k
    plot_u(indice) = llik(j+1) + (plot_x(indice) - x(j+1)).*grad(j+1);
end
plot(plot_x,plot_u,'color','red');

% mark tangent points
plot(x, llik, 'k+');

% plot lower hull function
plot_l = -inf(size(plot_x)); % initialise
for j = 2:length(z)-1
    indice = and(x(j) <= plot_x, plot_x < x(j+1));  % indice of plot_x in abscissae k
    plot_l(indice) = ((x(j+1) - plot_x(indice)).*llik(j) + (plot_x(indice) - x(j)).*llik(j+1)) ./ (x(j+1) - x(j));
end
plot(plot_x,plot_l,'color','green');  % squeezing function between x's 

YL = ylim;  % get the y limits
line([x(2) x(2)], [YL(1) llik(2)], 'color','green'); % squeezing function outside x's = -inf
line([x(end-1) x(end-1)], [YL(1) llik(end-1)], 'color','green'); % squeezing function outside x's = -inf

% axis([10,inf,-0.005,0.015]);
xlabel('x'); % x-axis label
ylabel('log likelihood'); % y-axis label

% draw the likelihood, envelope function and the squeezing function
figure;
hold on;

% plot likelihood
plot_f = g(plot_x);
plot(plot_x,plot_f,'color', 'blue');

% envelope function
plot(plot_x,exp(plot_u), 'color', 'red');

% squeezing function
plot(plot_x,exp(plot_l), 'color', 'green');

% mark tangent points
plot(x, exp(llik), 'k+');

XL = xlim;
YL = ylim;
axis([XL(1), XL(2), YL(1), 3]);
xlabel('x'); % x-axis label
ylabel('likelihood'); % y-axis labels

% draw the cdf of the envelope function
figure;
hold on;

% plot cdf
plot_c = zeros(size(plot_x)); % initialise
cum_temp = 0;  % temporary variable to store the cumulative
for j = 1:length(z)-1
    indice = and(z(j) <= plot_x, plot_x < z(j+1));  % indice of plot_x in abscissae k
    plot_c(indice) = cum_temp + 1./grad(j+1).*(exp(plot_u(indice)) - exp(u_z(j)));
    cum_temp = cum_temp + 1/grad(j+1)*(exp(u_z(j+1)) - exp(u_z(j)));
end
plot_c = plot_c / cum_temp;
plot(plot_x,plot_c,'color','red');

% plot the piecewise changing point
YL = ylim;  % get the y limits
for j = 1:length(z)
    line([z(j) z(j)], YL, 'color','blue', 'linestyle', ':'); 
end

xlabel('x'); % x-axis label
ylabel('cumulative density function'); % y-axis label





