function [ boolApproxEqual ] = approxEqual( values1, values2, significance )
%APPROXEQUAL Check if two values are close to each other
%   Return TRUE if the difference between [value1] and [value2] are within
%   the percentage difference given by [significance]
%
%   Input: 
%            values1 = first real values 
%            values2 = second real values 
%       significance = percentage difference [optional, default to 1e-8]
%
%   Output:
%       boolApproxEqual = TRUE if the values are approximately equal
%   

% set default significance if not provided
if nargin < 3
   significance = 1e-8;
end

% check differences
perDiff = abs(1 - (values1 + 1e-16) ./ (values2 + 1e-16));
boolApproxEqual = perDiff < significance;

end

